import java.io.*;
public class Ejercicio1 {
    
    public static void main(String[] args) {
        String namearch = "pares.txt";
        String namearchp = "impares.txt";
        FileWriter escribir ;
        FileWriter escribirp ;
        try {
           escribir = new FileWriter(namearch);
           escribirp = new FileWriter(namearchp);
           for (int i = 1 ; i <= 50 ; i++){
                if (i % 2 == 0) {
                  escribir.write(i+" | ");  
                }
                else {
                    escribirp.write(i+" | ");
                }
                    
                
           }
           escribirp.close();
           escribir.close();
        
        } catch (IOException e) {
            System.out.println("Imposible abrir el archivo para escribir");
        }
        FileReader leer ; 
        FileReader leerimp;
        try {
            leer = new FileReader(namearch);
            leerimp = new FileReader(namearchp);
            int c = leer.read();
            int d = leerimp.read();
            while (c != -1) {
                System.out.print((char)c);
                 
                c = leer.read();     
                                                                                                             
            }
            System.out.println(" ");
            while (d != -1) {
                
                 System.out.print((char)d);
                     
                d = leerimp.read();                                                                                               
            }
            leer.close();
        } catch (IOException e) {
            System.out.println("imposible abrir el archivo para leer");
        }

    }
}


