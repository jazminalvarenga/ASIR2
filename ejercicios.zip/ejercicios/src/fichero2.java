import java.io.*;

public class fichero2 {
    public static void main(String[] args) {
        String namearchivein = "./src/fichero2.java";
        String namearchiveout = "Ficheros2.num";
        
        String linea;
        int cont = 1;
        
        try  {
             FileReader leer = new FileReader(namearchivein);
             BufferedReader filtro = new BufferedReader(leer);
             FileWriter escribir = new FileWriter(namearchiveout);
             BufferedWriter filtroEscritura = new BufferedWriter(escribir);
            linea = filtro.readLine();
            
            while (linea != null) {
                System.out.println(cont + " . " + linea);
                filtroEscritura.write(cont + " . " + linea);
                filtroEscritura.newLine(); 
                linea = filtro.readLine();
                cont++;
            }
            filtro.close();
            filtroEscritura.close();
        } catch (IOException e) {
            System.out.println("Error: ");
        
        }
    }
}