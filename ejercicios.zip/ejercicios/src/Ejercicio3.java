import java.io.*;
public class Ejercicio3 {
    public static void main(String[] args) {
        String namearch = "datos.txt";
        int numLineas = 0;
        int numPalabras = 0;
        long numCaracteres = 0;
        long totalLongitudPalabras = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(namearch))) {
            
            String linea;
           
            while ((linea = br.readLine()) != null) {
                numLineas++;
                numCaracteres += linea.length(); 
                
                
                // .split("\\s+") divide por uno o más espacios/tabulaciones
                String[] palabrasEnLinea = linea.trim().split("\\s+");

                // Itero por cada palabra encontrada en la línea
                for (String palabra : palabrasEnLinea) {
                    // Ver si hay palabras vacías
                    if (palabra.isEmpty()) {
                        continue;
                    }
                    numPalabras++;
                    totalLongitudPalabras += palabra.length();
                }
            }

        } catch (IOException e) {
            System.out.println("Error ");
            
        }
       
        System.out.println("Número total de líneas: " + numLineas);
        System.out.println("Número total de palabras: " + numPalabras);
        System.out.println("Número total de caracteres: " + numCaracteres);
        System.out.println("Promedio longitud palabras: " + numCaracteres/numPalabras);
    }
}
