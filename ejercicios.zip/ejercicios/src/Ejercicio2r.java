import java.io.*;
import java.util.Scanner;
public class Ejercicio2r {
    public static void main(String[] args) {
        String archin = "texto.txt";
        String archout = "texto_modificado2.txt";
        FileReader leer ;
        FileWriter escribir ;
        BufferedReader leerlinea;
        BufferedWriter escribirlinea ;
        String linea ;
        try {
            Scanner sc = new Scanner(System.in);
            System.out.println("Que caracteres desea reemplazar , escribelos juntos sin espacio ni comas ");
            String originals = sc.nextLine();
            System.out.println("Que caracteres desea poner en su lugar , escribelos juntos sin espacio ni comas ");
            String reemplazos = sc.nextLine();

            leer = new FileReader(archin);
            leerlinea = new BufferedReader(leer);
            
            escribir = new FileWriter(archout);
            escribirlinea = new BufferedWriter(escribir);
            
            
            
            while ((linea = leerlinea.readLine()) != null) {

                for (int i = 0; i < originals.length(); i++) {
                    
                    
                    char original = originals.charAt(i);
                    
                    
                    char reemplazo = reemplazos.charAt(i);
                    
                    linea = linea.replace(original, reemplazo);
                }
                escribirlinea.write(linea);
                escribirlinea.newLine();
            }
            leerlinea.close();
            escribirlinea.close();
            
        
            

        } catch (IOException e) {
            System.out.println("Error");
        }

    }
}