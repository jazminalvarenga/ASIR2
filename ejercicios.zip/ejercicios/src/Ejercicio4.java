import java.io.*;
import java.util.Scanner;
public class Ejercicio4 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("De cuantos caracteres deseas las palabras");
        int longword = sc.nextInt();
        String namearch = "palabras.txt";
        String namedest = "palabras_largas.txt";
        
        
        try (BufferedReader br = new BufferedReader(new FileReader(namearch));
            BufferedWriter wr = new BufferedWriter(new FileWriter(namedest))) {
            
            String linea;
            
           
            while ((linea = br.readLine()) != null) {
                
                
                
                // .split("\\s+") divide por uno o más espacios/tabulaciones
                String[] palabrasEnLinea = linea.trim().split("\\s+");

                // Itero por cada palabra encontrada en la línea
                for (String palabra : palabrasEnLinea) {
                    // Ver si hay palabras vacías
                    if (palabra.isEmpty()) {
                        continue;
                    }
                    if (palabra.length() > longword) {
                        wr.write(palabra+ " "); // Escribe la palabra
                             // 3. Añade un salto de línea para legibilidad
                    }
                    
                    
                } wr.newLine();
            } 

        } catch (IOException e) {
            System.out.println("Error ");
            
        }
       
    }
}
