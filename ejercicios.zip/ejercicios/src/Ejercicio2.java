import java.io.*;
public class Ejercicio2 {
    public static void main(String[] args) {
        String archin = "texto.txt";
        String archout = "texto_modificado.txt";
        FileReader leer ;
        FileWriter escribir ;
        BufferedReader leerlinea;
        BufferedWriter escribirlinea ;
        String linea ;
        try {
            leer = new FileReader(archin);
            leerlinea = new BufferedReader(leer);
            
            escribir = new FileWriter(archout);
            escribirlinea = new BufferedWriter(escribir);
            String minisuculas = "aeiou";
            
            
            while ((linea = leerlinea.readLine()) != null) {

                for (int i = 0; i < minisuculas.length(); i++) {
                    
                    
                    char minuscula = minisuculas.charAt(i);
                    
                    
                    char mayuscula = Character.toUpperCase(minuscula);
                    
                    linea = linea.replace(minuscula, mayuscula);
                }
                escribirlinea.write(linea);
                escribirlinea.newLine();
            }
            leerlinea.close();
            escribirlinea.close();
            
        
            

        } catch (IOException e) {
            System.out.println("Error");
        }

    }
}
