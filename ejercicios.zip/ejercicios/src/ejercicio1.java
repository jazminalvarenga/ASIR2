import java.io.*;
public class ejercicio1 {
    
    public static void main(String[] args) {
        String namearch = "pares.txt";
        String namearchp = "impares.txt";
        FileWriter escribir ;
        FileWriter escribirp ;
        try {
           escribir = new FileWriter(namearch);
           escribirp = new FileWriter(namearchp);
           for (int i = 1 ; i <= 50 ; i++){
                if (i % 2 == 0) {
                  escribir.write(i+" | ");  
                }
                if (i % 2 == 0) {
                  escribirp.write(i+" | ");  
                }
           }
           escribir.close();
        
        } catch (IOException e) {
            System.out.println("Imposible abrir el archivo para escribir");
        }
        FileReader leer ; 
        
        try {
            leer = new FileReader(namearch);
            int c = leer.read();
            while (c != -1) {
                System.out.print((char)c);
                c = leer.read();                                                                                                    
            }
            leer.close();
        } catch (IOException e) {
            System.out.println("imposible abrir el archivo para leer");
        }

    }
}


