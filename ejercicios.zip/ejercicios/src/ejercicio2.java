public class ejercicio2 {
    
}
