import java.util.Random;
import java.util.Scanner ;
import java.util.random.*;
import java.util.Arrays;

public class Seis {
	
	
	public static int[] generaprimitiva(){
		Random random = new Random();
		int[]primitiva = new int[6];
		
		// agregamos al array sin repetir
		for (int i = 0 ; i < 6;i++) {
			int numero = random.nextInt(1,50);
			boolean repetido = false;
			
			// Recorro lo que tengo hasta ahora del array buscando el nuevo random
	        for (int j = 0; j < i; j++) {
	            if (primitiva[j] == numero) {
	                repetido = true;
	                break; 
	            }
	        }
			if (repetido) {
				i--;	
			}
			else {
				primitiva[i] = numero ;
			}	
		}
		
		
		return primitiva;
	}

	public static void main(String[] args) {
		long inicio = System.nanoTime();
		Scanner sc = new Scanner(System.in);
		
        // Llamamos a la funcion y creamos la primitiva original
        String primitiva = Arrays.toString(generaprimitiva());
        boolean esigual = true;
        int contador = 0 ;
        while(esigual) {
        	String primitivauser = Arrays.toString(generaprimitiva());
        	if (primitivauser.equals(primitiva) ) {
        		esigual = false ;
        		System.out.println("Tu boleto es igual a la primitiva " + primitivauser + " = " + primitiva );
        	}
        	else {
        		System.out.println("Quieres tirar otra s/n");
        		String opcion = sc.nextLine();
        		if (opcion.equals("n")) {
        			esigual = false ;
        			contador--;
        		}
        		contador++;
        	}
        }
        System.out.println("Has ganado en " + contador + " intentos");
        
        
        // Contador de tiempo 
        long fin = System.nanoTime();
        long tiempo = fin - inicio;
        System.out.println("\nTiempo que tarda: " + tiempo + " nanosegundos");
        System.out.println("Tiempo que tarda: " + (tiempo / 1000000.0) + " milisegundos");
        
	}

}

