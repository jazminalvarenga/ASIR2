import java.io.*;

public class ficheros {
    public static void main(String[] args) {
        String namearch = "prueba.txt";
        FileWriter escribir ;
        try {
           escribir = new FileWriter(namearch);
           for (char c = 'a' ; c <= 'z' ; c++){
                escribir.write(c);
           }
           escribir.close();
        
        } catch (IOException e) {
            System.out.println("Imposible abrir el archivo para escribir");
        }
        FileReader leer ;
        int c;
        try {
            leer = new FileReader(namearch);
            c = leer.read();
            while (c != -1) {
                System.out.print((char)c);
                c = leer.read();                                                                                                    
            }
            leer.close();
        } catch (IOException e) {
            System.out.println("imposible abrir el archivo para leer");
        }

    }
}
